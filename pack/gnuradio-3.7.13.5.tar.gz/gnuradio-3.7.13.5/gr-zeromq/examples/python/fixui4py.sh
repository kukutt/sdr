#!/bin/bash
sed -i 's/qwt_plot.h/PyQt4.Qwt5.Qwt/' $1
