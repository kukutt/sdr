The primary source of documentation is the wiki on github:

https://github.com/mossmann/hackrf/wiki

This directory contains supplemental documentation.

(photo jawbreaker-fd0-145436.jpeg by fd0 from https://github.com/fd0/jawbreaker-pictures)
